
package master.flame.danmaku.danmaku.model;

public class AlphaValue {

    public static int MAX = 255;

    public static int TRANSPARENT = 0;

}
