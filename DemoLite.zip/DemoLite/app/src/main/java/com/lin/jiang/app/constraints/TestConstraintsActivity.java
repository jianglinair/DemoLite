package com.lin.jiang.app.constraints;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.lin.jiang.app.R;

public class TestConstraintsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_contraints);
    }
}
