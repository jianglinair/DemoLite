package com.lin.jiang.app.constraints;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.lin.jiang.app.R;


public class ConstraintsLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_constraints_layout);
    }
}
