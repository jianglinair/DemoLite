package com.lin.jiang.app.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.lin.jiang.app.R;

/**
 * @author Administrator
 */
public class DrawActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_draw);
    }
}
